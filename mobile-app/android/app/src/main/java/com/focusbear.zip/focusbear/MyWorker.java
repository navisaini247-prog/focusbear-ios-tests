package com.focusbear;

import static android.content.Context.WINDOW_SERVICE;

import static com.focusbear.MainApplication.maincontext;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;

/*
 Created by "Jayant Sharma" on 21/06/22.
*/
public class MyWorker extends Worker {
   private Context mContext=null;
   private ReactApplicationContext reactApplicationContext;

   public MyWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
      super(context, workerParams);
      mContext=context;
   }
   @NonNull
   @Override
   public Result doWork() {
      Log.d("WORKER_TAG","Task completed successfully called");


      // create an instance of Window class and display the content on screen along with foreground service

//      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//         mContext.startForegroundService(new Intent(mContext, ForegroundService.class));
//      } else {
//         mContext.startService(new Intent(mContext, ForegroundService.class));
//      }

      Handler handler = new Handler(Looper.getMainLooper());
      handler.postDelayed(new Runnable() {
         @RequiresApi(api = Build.VERSION_CODES.P)
         @Override
         public void run() {

            // create an instance of Window class
            // and display the content on screen
            OverlayControl.getInstance(mContext).addListener();
//            Window.getInstance(mContext).open();
//            WritableMap params = Arguments.createMap();
//            params.putBoolean("START_SERVICE", true);
//            Log.e("event--11>>","event--22>>"+ reactApplicationContext + params);
////            maincontext.getReactNativeHost().getReactInstanceManager().getCurrentReactContext()
////                    .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
////                    .emit("OVERLAY_SERVICE", params);
//            Events.getInstance(maincontext.getReactNativeHost().getReactInstanceManager().getCurrentReactContext())
//                    .sendEvent("OVERLAY_SERVICE",params);
         }
      }, 1000 );

      return Result.success();
   }
}