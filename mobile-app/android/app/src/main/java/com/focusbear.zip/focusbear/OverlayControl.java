package com.focusbear;

import static android.content.Context.ACTIVITY_SERVICE;
import static android.content.Context.WINDOW_SERVICE;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Telephony;
import android.telecom.TelecomManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import androidx.annotation.RequiresApi;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactMethod;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;

public class OverlayControl {
    private Context context;
    public static OverlayControl overlayControl = null;
    private Timer myTimer;
    TimerTask myTask;
    private Boolean overlayEnabled = false;
    String defaultSMSPackageName = "vnd.android-dir/mms-sms";

    private OverlayControl(Context context){
        this.context = context;
    }

    private OverlayControl(){

    }

    public static OverlayControl getInstance(Context context){
        if (overlayControl == null) {
            overlayControl = new OverlayControl(context);
        }
        return overlayControl;
    }
    /**
     * Listener which run after some time interval to call foreground app method
     * and to decide whether to show overlay popup or we have to hide that.
     */
    @RequiresApi(api = Build.VERSION_CODES.P)
    public void addListener(){
        if (overlayEnabled) {
            stopService(true);
        }
        String defaultDialer = isDefaultDialer();
        String defaultMsg = isDefaultMessageApp();
        String defaultLauncher = isDefaultLauncher();
        myTimer = new Timer();
        myTask = new TimerTask() {
            @RequiresApi(api = Build.VERSION_CODES.P)
            @Override
            public void run() {
                //your method
                String runningApp = getForegroundApp();
                String PACKAGE_NAME = context.getPackageName();
                if (!runningApp.equals(PACKAGE_NAME) && !runningApp.equals(defaultDialer) && !runningApp.equals(defaultMsg) && !runningApp.equals(defaultLauncher)) {
                    Log.e("notifications--30>>","notifications--11>>"+ defaultDialer + PACKAGE_NAME);
                    if (overlayEnabled != true){
                        overlayEnabled = true;
                        Window.getInstance(context).open();

                    }
                } else {
                    Log.e("notifications--30>>","notifications--22>>"+ defaultDialer);
                    stopService(false);
                }
            }
        };
        myTimer.scheduleAtFixedRate(myTask,0,5000); //put here time 1000 milliseconds=1 second
    }

    /**
     * Returns the name of the package currently in foreground.
     */
    @RequiresApi(api = Build.VERSION_CODES.P)
    public String getForegroundApp() {
        String currentApp = "NULL";
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            UsageStatsManager usage = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
            long time = System.currentTimeMillis();
            // long beginTime = time - 60000;
            long beginTime = time - 1000 * 1000;
            List<String> packageNames = new ArrayList<>();
            UsageEvents usageEvents = usage.queryEvents(beginTime, time);
            UsageEvents.Event event = new UsageEvents.Event();
            while (usageEvents.hasNextEvent()) {
                usageEvents.getNextEvent(event);
                if (event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    if (!packageNames.contains(event.getPackageName())) {
                        packageNames.add(event.getPackageName());
                    }
                }
                if (event.getEventType() == UsageEvents.Event.MOVE_TO_BACKGROUND) {
//                    if (!packageNames.contains(event.getPackageName())) {
//                        packageNames.add(event.getPackageName());
//                    }
                }

                if (event.getEventType() == UsageEvents.Event.ACTIVITY_STOPPED) {
//                    if (packageNames.contains(event.getPackageName())) {
//                        packageNames.remove(event.getPackageName());
//                    }
                }
            }

            List<UsageStats> appList = usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, beginTime, time);

            if (appList != null && appList.size() > 0) {
                SortedMap<Long, UsageStats> mySortedMap = new TreeMap<Long, UsageStats>();
                for (UsageStats usageStats : appList) {
                    mySortedMap.put(usageStats.getLastTimeUsed(), usageStats);
                }
                if (mySortedMap != null && !mySortedMap.isEmpty()) {
                    currentApp = mySortedMap.get(mySortedMap.lastKey()).getPackageName();
                }
            }
        } else {
            ActivityManager am = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
            List<ActivityManager.RunningAppProcessInfo> tasks = am.getRunningAppProcesses();
            currentApp = tasks.get(0).processName;
        }
        return currentApp;
    }

    /**
     * Returns the package name of Default dialer of mobile.
     * @return
     */
    public String isDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            TelecomManager manager = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
            return manager.getDefaultDialerPackage();
        }
        return null ;//Change it based on your requirement.
    }

    /**
     * Returns package name of default messaging app of mobile.
     * @return
     */
    public String isDefaultMessageApp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            String defaultSmsPackageName = Telephony.Sms.getDefaultSmsPackage(context);
            if (defaultSmsPackageName != null) {
                return defaultSmsPackageName;
            }
        }
        return  defaultSMSPackageName;
    }

    /**
     * Returns package name of launcher/home in mobile phone.
     * @return
     */
    public String isDefaultLauncher() {
        PackageManager localPackageManager = context.getPackageManager();
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        String str = localPackageManager
                .resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                .activityInfo
                .packageName;
        return str;
    }

    /**
     * React Method called from android also to stop overlay functionality.
     * @param permanent It's boolean value on the basis of which
     *                 we decide to permanent hide overlay or for some time.
     */
    public void stopService(boolean permanent) {
       Window.getInstance(context).close();

    }
}
