package com.focusbear;

import static com.focusbear.MainActivity.mainActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.facebook.react.bridge.ReactApplicationContext;

public class AlarmReceiver extends BroadcastReceiver {
    public AlarmReceiver() {
    }

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    public void onReceive(Context context, Intent intent) {
//        Intent intent = mainActivity.getPackageManager().getLaunchIntentForPackage(
//                mainActivity.getPackageName());
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
//        mainActivity.startActivity(intent);
//        mainActivity.startActivity(intent,MainActivity.class);
//        OverlayModule student = new OverlayModule((ReactApplicationContext) context);
//        student.addListener();
    }

}
