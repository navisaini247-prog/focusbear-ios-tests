package com.focusbear;

import android.util.Log;

import androidx.annotation.Nullable;

import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;

public class Events {
    private ReactContext reactContext;
    public static Events events = null;

    private Events(ReactContext reactContext){
        this.reactContext = reactContext;
    }

    private Events(){

    }

    public static Events getInstance(ReactContext reactContext){
        if (events == null) {
            events = new Events(reactContext);
        }
        return events;
    }

    /**
     * Send event to javascript side from android side.
     * @param eventName
     * @param params
     */
    public void sendEvent(String eventName, @Nullable WritableMap params) {
        Log.e("event--11>>","event--33>>"+ eventName + "-->>"+ reactContext + "-->>" + params);
        reactContext
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit(eventName, params);
    }
}
