package com.focusbear;

import static android.content.Context.WINDOW_SERVICE;

import static com.focusbear.MainApplication.maincontext;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.WritableMap;

/*
 Created by "Jayant Sharma" on 22/06/22.
*/
public class Window {

   // declaring required variables
   private Context context;
   private View mView;
   private WindowManager.LayoutParams mParams;
   private WindowManager mWindowManager;
   private LayoutInflater layoutInflater;
   private ReactApplicationContext reactApplicationContext;
   public static Window window = null;

   private Window(){

   }

   public static Window getInstance(Context context){
      if (window == null) {
         window = new Window(context);
      }
      return window;
   }

   private Window(Context context){
      this.context=context;

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
         // set the layout parameters of the window
         mParams = new WindowManager.LayoutParams(
                 // Shrink the window to wrap the content rather
                 // than filling the screen
                 WindowManager.LayoutParams.MATCH_PARENT, 600,
                 // 100, 100,
                 // Display it on top of other application windows
                 WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                 // Don't let it grab the input focus
                 WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                 // Make the underlying application window visible
                 // through any transparent parts
                 PixelFormat.TRANSLUCENT);

      }
      // getting a LayoutInflater
       layoutInflater  = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
      // inflating the view with the custom layout we created
       mView = layoutInflater.inflate(R.layout.overlayview, null);
      // set onClickListener on the remove button, which removes
      // the view from the window
      mView.findViewById(R.id.window_close).setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
            WritableMap params = Arguments.createMap();
            params.putBoolean("OPEN_APP", true);
         }
      });
      // Define the position of the
      // window within the screen
      mParams.gravity = Gravity.CENTER;
      mWindowManager = (WindowManager)context.getSystemService(WINDOW_SERVICE);

   }

   public void open() {

      try {
         // check if the view is already
         // inflated or present in the window
         if(mView.getWindowToken()==null) {
            if(mView.getParent()==null) {
               mWindowManager.addView(mView, mParams);
            }
         }
      } catch (Exception e) {
         Log.d("Error1",e.toString());
      }

   }

   public void close() {

      try {
         // remove the view from the window
         ((WindowManager)context.getSystemService(WINDOW_SERVICE)).removeView(mView);
         // invalidate the view
         mView.invalidate();
         // remove all views
         ((ViewGroup)mView.getParent()).removeAllViews();

         // the above steps are necessary when you are adding and removing
         // the view simultaneously, it might give some exceptions
      } catch (Exception e) {
         Log.d("Error2",e.toString());
      }
   }
}
