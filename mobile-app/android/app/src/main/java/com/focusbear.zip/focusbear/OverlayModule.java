package com.focusbear;

import static android.content.Context.ACTIVITY_SERVICE;
import static android.content.Context.WINDOW_SERVICE;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.provider.Telephony;
import android.telecom.TelecomManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.SortedMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;

public class OverlayModule extends ReactContextBaseJavaModule {
    static ReactApplicationContext reactContext;
    private View mView;
    private WindowManager.LayoutParams mParams;
    private WindowManager mWindowManager;
    private LayoutInflater layoutInflater;
    private Timer myTimer;
    TimerTask myTask;
    private Boolean overlayEnabled = false;
    String defaultSMSPackageName = "vnd.android-dir/mms-sms";
    String MobilePackage = "";
    SharedPreferences mPrefs;
    static OverlayModule obj;

    OverlayModule(ReactApplicationContext context) {
        super(context);
        reactContext = context;
        obj = this;
    }
    @NonNull
    @Override
    public String getName() {
        return "OverlayModule";
    }

    public static OverlayModule getObject(){
      return obj;
    };

    @ReactMethod
    public void getPhoneID(Promise response) {
        try {
            @SuppressLint("HardwareIds") String id = Settings.Secure.getString(reactContext.getContentResolver(), Settings.Secure.ANDROID_ID);
            response.resolve(id);
        } catch (Exception e) {
            response.reject("Error", e);
        }
    }

    /**
     * Send event to javascript side from android side.
     * @param eventName
     * @param params
     */
    public void sendEvent(ReactContext reactContext,
                           String eventName,
                           @Nullable WritableMap params) {
        Log.e("event--11>>","event--33>>"+ eventName + "-->>"+ reactContext + "-->>" + params);
        reactContext
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit(eventName, params);
    }

//    public void sendEvent(String eventName,
//                          @Nullable WritableMap params) {
//        Log.e("event--11>>","event--33>>"+ eventName + reactContext + params);
//        reactContext
//                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
//                .emit(eventName, params);
//    }


    /**
     * React Method to start overlay schedule service.
     * @param promise
     */
    @RequiresApi(api = Build.VERSION_CODES.P)
    @ReactMethod
    public void startService(Promise promise) {
        String result = "Success";
        addListener();
    }

    /**
     * This method to start overlay popup, It includes popup design and buttons.
     */
    public void showOverlay() {
       // Activity activity = getCurrentActivity();
        new Handler(Looper.getMainLooper()).postDelayed(
                new Runnable() {
                    public void run() {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            // set the layout parameters of the window
                            mParams = new WindowManager.LayoutParams(
                                    // Shrink the window to wrap the content rather
                                    // than filling the screen
                                    WindowManager.LayoutParams.MATCH_PARENT, 600,
                                   // 100, 100,
                                    // Display it on top of other application windows
                                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                                    // Don't let it grab the input focus
                                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                                    // Make the underlying application window visible
                                    // through any transparent parts
                                    PixelFormat.TRANSLUCENT);

                        }
                        // getting a LayoutInflater
                        layoutInflater = (LayoutInflater) reactContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        // inflating the view with the custom layout we created
                        mView = layoutInflater.inflate(R.layout.overlayview, null);
//                        TextView textView = (TextView) findViewById(R.id.window_close);
//                        setPaintFlags(textView.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
                        // set onClickListener on the remove button, which removes
                        // the view from the window
                        mView.findViewById(R.id.window_close).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                stopService(false,null);
                                WritableMap params = Arguments.createMap();
                                params.putBoolean("OPEN_APP", true);
                                sendEvent(reactContext,"OVERLAY_SERVICE",params);
                            }
                        });
//                        mView.findViewById(R.id.window_permanent_close).setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View v) {
//                                stopService(true,null);
//                                WritableMap params = Arguments.createMap();
//                                params.putBoolean("STOP", true);
//                                sendEvent(reactContext,"OVERLAY_SERVICE",params);
//                            }
//                        });
                        // Define the position of the
                        // window within the screen
                        mParams.gravity = Gravity.CENTER;
                        mWindowManager = (WindowManager)reactContext.getSystemService(WINDOW_SERVICE);

                        try {
                            // check if the view is already
                            // inflated or present in the window
                            if(mView.getWindowToken()==null) {
                                if(mView.getParent()==null) {
                                    mWindowManager.addView(mView, mParams);
                                }
                            }
                        } catch (Exception e) {
                            Log.e("SHOW_OVERLAY",e.getMessage());
                        }
                       // promise.resolve(result);
                    }
                }, 1000);
    }

    /**
     * This method to stop overlay popup with timer, It includes popup design and buttons.
     */
    @ReactMethod
    public void stopOverlayService(int time, Promise promise) {
        Log.e("notifications--30>>","notifications--1040>>"+ time + overlayEnabled);
        new Handler(Looper.getMainLooper()).postDelayed(
                new Runnable() {
                    public void run() {
                        Log.e("notifications--30>>","notifications--1050>>"+ time + overlayEnabled);
                        stopService(true,null);
                        WritableMap params = Arguments.createMap();
                        params.putBoolean("STOP", true);
                        sendEvent(reactContext,"OVERLAY_SERVICE",params);
                    }
                }, time);
    }

    /**
     * React Method called from android also to stop overlay functionality.
     * @param permanent It's boolean value on the basis of which
     *                 we decide to permanent hide overlay or for some time.
     * @param promise
     */
    @ReactMethod
    public void stopService(boolean permanent,Promise promise) {
        try {
            Log.e("notifications--30>>","notifications--1010>>"+ permanent + overlayEnabled);

            if (permanent == true) {
                myTimer.cancel();
//                WritableMap params = Arguments.createMap();
//                params.putBoolean("STOP", true);
//                sendEvent(reactContext,"OVERLAY_SERVICE",params);
            }
            if (overlayEnabled == true) {
                overlayEnabled = false;
            }
            if (mView != null) {
                // remove the view from the window
                ((WindowManager) reactContext.getSystemService(WINDOW_SERVICE)).removeView(mView);
                // invalidate the view
                mView.invalidate();
                // remove all views
                ((ViewGroup) mView.getParent()).removeAllViews();
                // promise.resolve(true);
            }
            Log.e("notifications--30>>","notifications--1020>>"+ overlayEnabled);
            // the above steps are necessary when you are adding and removing
            // the view simultaneously, it might give some exceptions
        } catch (Exception e) {
           // promise.reject("Error", "Error");
        }
    }

    /**
     * Listener which run after some time interval to call foreground app method
     * and to decide whether to show overlay popup or we have to hide that.
     */
    @RequiresApi(api = Build.VERSION_CODES.P)
    public void addListener(){
        Activity activity = getCurrentActivity();
        if (overlayEnabled) {
            stopService(true,null);
        }
        String defaultDialer = isDefaultDialer();
        String defaultMsg = isDefaultMessageApp();
        String defaultLauncher = isDefaultLauncher();
//        Gson gson = new Gson();
//        String json = mPrefs.getString("MyObject", "");
//        Schedule obj = gson.fromJson(json, Schedule.class);
        Log.e("notifications--30>>","notifications--00>>"+ defaultDialer);
        myTimer = new Timer();
        myTask = new TimerTask() {
            @RequiresApi(api = Build.VERSION_CODES.P)
            @Override
            public void run() {
                //your method
               String runningApp = getForegroundApp();
                String PACKAGE_NAME = getReactApplicationContext().getPackageName();
               if (!runningApp.equals(PACKAGE_NAME) && !runningApp.equals(defaultDialer) && !runningApp.equals(defaultMsg) && !runningApp.equals(defaultLauncher)) {
                   Log.e("notifications--30>>","notifications--11>>"+ defaultDialer + PACKAGE_NAME);
                   if (overlayEnabled != true){
                       overlayEnabled = true;
                       showOverlay();
                   }
               } else {
                   Log.e("notifications--30>>","notifications--22>>"+ defaultDialer);
                   stopService(false,null);
               }
            }
        };
        myTimer.scheduleAtFixedRate(myTask,0,5000); //put here time 1000 milliseconds=1 second
    }

    /**
     * Returns the name of the package currently in foreground.
     */
    @RequiresApi(api = Build.VERSION_CODES.P)
    public String getForegroundApp() {
        String currentApp = "NULL";
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            UsageStatsManager usage = (UsageStatsManager) reactContext.getSystemService(Context.USAGE_STATS_SERVICE);
            long time = System.currentTimeMillis();
           // long beginTime = time - 60000;
            long beginTime = time - 1000 * 1000;
            List<String> packageNames = new ArrayList<>();
            UsageEvents usageEvents = usage.queryEvents(beginTime, time);
            UsageEvents.Event event = new UsageEvents.Event();
            while (usageEvents.hasNextEvent()) {
                usageEvents.getNextEvent(event);
                if (event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    if (!packageNames.contains(event.getPackageName())) {
                        packageNames.add(event.getPackageName());
                    }
                }
                if (event.getEventType() == UsageEvents.Event.MOVE_TO_BACKGROUND) {
//                    if (!packageNames.contains(event.getPackageName())) {
//                        packageNames.add(event.getPackageName());
//                    }
                }

                if (event.getEventType() == UsageEvents.Event.ACTIVITY_STOPPED) {
//                    if (packageNames.contains(event.getPackageName())) {
//                        packageNames.remove(event.getPackageName());
//                    }
                }
            }

            List<UsageStats> appList = usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, beginTime, time);

            if (appList != null && appList.size() > 0) {
                SortedMap<Long, UsageStats> mySortedMap = new TreeMap<Long, UsageStats>();
                for (UsageStats usageStats : appList) {
                    mySortedMap.put(usageStats.getLastTimeUsed(), usageStats);
                }
                if (mySortedMap != null && !mySortedMap.isEmpty()) {
                    currentApp = mySortedMap.get(mySortedMap.lastKey()).getPackageName();
                }
            }
        } else {
            ActivityManager am = (ActivityManager) reactContext.getSystemService(ACTIVITY_SERVICE);
            List<ActivityManager.RunningAppProcessInfo> tasks = am.getRunningAppProcesses();
            currentApp = tasks.get(0).processName;
        }
        return currentApp;
    }

    /**
     * Returns the package name of Default dialer of mobile.
     * @return
     */
    public String isDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            TelecomManager manager = (TelecomManager) reactContext.getSystemService(Context.TELECOM_SERVICE);
            return manager.getDefaultDialerPackage();
        }
        return null ;//Change it based on your requirement.
    }

    /**
     * Returns package name of default messaging app of mobile.
     * @return
     */
    public String isDefaultMessageApp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            String defaultSmsPackageName = Telephony.Sms.getDefaultSmsPackage(reactContext);
            if (defaultSmsPackageName != null) {
                return defaultSmsPackageName;
            }
        }
        return  defaultSMSPackageName;
    }

    /**
     * Returns package name of launcher/home in mobile phone.
     * @return
     */
    public String isDefaultLauncher() {
        PackageManager localPackageManager = reactContext.getPackageManager();
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        String str = localPackageManager
                .resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                .activityInfo
                .packageName;
        return str;
    }


}
