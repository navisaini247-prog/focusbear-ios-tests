package com.focusbear;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;


/*
 Created by "Jayant Sharma" on 22/06/22.
*/
public class ForegroundService extends Service {
   public ForegroundService() {
   }

   @Override
   public IBinder onBind(Intent intent) {
      throw new UnsupportedOperationException("Not yet implemented");
   }

   @Override
   public void onCreate() {
      super.onCreate();
      Log.e("WORKER_TAG","Foreground service started");


      // create the custom or default notification
      // based on the android version
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
         startMyOwnForeground();
      else
         startForeground(1, new Notification());

      // create an instance of Window class
      // and display the content on screen
      Window.getInstance(this).open();
   }

   @Override
   public int onStartCommand(Intent intent, int flags, int startId) {
      return super.onStartCommand(intent, flags, startId);
   }

   // for android version >=O we need to create
   // custom notification stating
   // foreground service is running
   @RequiresApi(Build.VERSION_CODES.O)
   private void startMyOwnForeground()
   {
      String NOTIFICATION_CHANNEL_ID = "example.permanence";
      String channelName = "Background Service";
      NotificationChannel chan = new NotificationChannel(NOTIFICATION_CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_MIN);

      NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
      assert manager != null;
      manager.createNotificationChannel(chan);

      NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);
      Notification notification = notificationBuilder
//              .setOngoing(true)
              .setContentTitle("Service running")
              .setContentText("Displaying over other apps")

              // this is important, otherwise the notification will show the way
              // you want i.e. it will show some default notification
              .setSmallIcon(android.R.drawable.ic_notification_overlay)

              .setPriority(NotificationManager.IMPORTANCE_MIN)
              .setCategory(Notification.CATEGORY_SERVICE)
              .build();
      startForeground(2, notification);
   }
}
